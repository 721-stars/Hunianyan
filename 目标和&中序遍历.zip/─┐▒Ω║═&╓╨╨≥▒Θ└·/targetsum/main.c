#include <stdio.h>
#include <stdlib.h>
void DFS(int* nums, int S,int k,int* count,int sum,int l)    {
    if(k==l)        {
        if(sum==S)            {
            ++(*count);
        }
        return;
    }
    DFS(nums, S,k+1,count,sum+nums[k],l);
    DFS(nums, S, k+1,count,sum-nums[k],l);
    //printf("%d\n",*count);
}
int findTargetSumWays(int* nums, int S,int l)     {
    int count=0;
    int sum=0;
    DFS(nums,S,0,&count,sum,l);
    return count;
}
main(){
    int count,l;
    int num[5]={1,1,1,1,1};
    int S=3;
    l=sizeof(num)/sizeof(num[0]);
    count=findTargetSumWays(num,S,l);
    printf("�ܹ���%d�ַ���\n",count);
}
