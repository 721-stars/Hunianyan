# -*- coding: utf-8 -*-
"""
Created on Tue Nov 26 18:50:03 2019

@author: Administrator
"""
class Solution:
    def firstBadVersion(self, n):
        """
        :type n: int
        :rtype: int
        """
        l,r=0,n
        while l<r:
            mid=(l+r)//2
            if isBadVersion(mid):
                r=mid
            else:
                l=mid+1
        return r
    
def isBadVersion(version):
        if version>=4:
            return True
        else:
            return False
    
if __name__ == "__main__":
    print(Solution().firstBadVersion(5))
