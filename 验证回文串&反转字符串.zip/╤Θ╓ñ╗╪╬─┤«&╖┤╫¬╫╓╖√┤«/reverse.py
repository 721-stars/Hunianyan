# -*- coding: utf-8 -*-
"""
Created on Tue Nov  5 15:18:27 2019

@author: Administrator
"""
class Solution:
    def reverseString(self, s):
         """
         :type s: List[str]
         :rtype: void Do not return anything, modify s in-place instead.
         """
         for i in range(len(s) // 2):
             temp = s[i]
             s[i] = s[-i - 1]
             s[-i - 1] = temp
         return 
if __name__=="__main__":
     s=Solution()
     list = [1,2,3,'l','o']
     print(s.reverseString(list))
