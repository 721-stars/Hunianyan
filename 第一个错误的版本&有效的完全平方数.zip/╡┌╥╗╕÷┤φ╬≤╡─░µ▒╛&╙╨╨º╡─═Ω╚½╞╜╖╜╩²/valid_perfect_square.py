# -*- coding: utf-8 -*-
"""
Created on Tue Nov 26 19:10:14 2019

@author: Administrator
"""
class Solution:
    def isPerfectSquare(self, num: int) -> bool:
        l, r = 1, num
        while l < r:
            mid = (l + r) // 2
            if mid * mid < num:
                l = mid + 1
            else:
                r = mid
        return l * l == num
    
if __name__=="__main__":
    num=eval(input("请一个数值："))
    print(Solution().isPerfectSquare(num))
