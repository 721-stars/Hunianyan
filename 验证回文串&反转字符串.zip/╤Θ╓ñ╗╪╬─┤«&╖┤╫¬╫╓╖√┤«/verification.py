# -*- coding: utf-8 -*-
"""
Created on Tue Nov  5 14:52:16 2019

@author: Administrator
"""
class Solution:

    def isPalindrome(self, s):
        """
        :type s: str
        :rtype: bool
        """
        if s=="":
            return True
        s=s.lower()#转换字符串中所有大写字符为小写
        s1=[]
        for i in range(0,len(s)):#这个循环将输入的字符串中去除数字和字母以外的字符
            if s[i].isalpha() or s[i].isdigit():
            #.isalpha()判断该字符是否为字母，.isdigit()判断该字符是否为数字
                s1.append(s[i])        
        j=len(s1)-1
        i=0
        while i<j:#双指针判断对称字符是否相等
            if s1[i]!=s1[j]:
                return False
            i=i+1
            j=j-1
        return True
if __name__ == "__main__":
    s = "A man, a plan, a canal: Panama"
    print(Solution().isPalindrome(s))
