# -*- coding: utf-8 -*-
"""
Created on Tue Nov 19 11:19:46 2019

@author: Administrator
"""
class Solution:
    def containsNearbyDuplicate(self, nums, k):
        record = {}
        for i, num in enumerate(nums):
            if num in record and i - record[num] <= k:
                return True
            record[num] = i
        return False

if __name__ == "__main__":
    points = [40,30,16,40,50]
    k = 2
    print(Solution().containsNearbyDuplicate(points, k))
