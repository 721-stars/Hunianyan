#include <stdio.h>
#include <stdlib.h>
typedef struct {
    int head;
    int tail;
    int data[1000];
    int size;
} MyCircularQueue;

/** Initialize your data structure here. Set the size of the queue to be k. */

MyCircularQueue* myCircularQueueCreate(int k) {
    MyCircularQueue* p;
    p=(MyCircularQueue*)malloc(sizeof(MyCircularQueue));
    p->size=k;
    p->head=-1;
    p->tail=-1;
    return p;
}

/** Insert an element into the circular queue. Return true if the operation is successful. */
int myCircularQueueEnQueue(MyCircularQueue* obj, int value) {
    int myCircularQueueIsFull(MyCircularQueue* obj);
    int myCircularQueueIsEmpty(MyCircularQueue* obj);
  if(myCircularQueueIsFull(obj))
      return 0;
    if(myCircularQueueIsEmpty(obj))
        obj->head=0;
    obj->tail=(obj->tail+1)%obj->size;
    obj->data[obj->tail]=value;
    return 1;
}

/** Delete an element from the circular queue. Return true if the operation is successful. */
int myCircularQueueDeQueue(MyCircularQueue* obj) {
    int myCircularQueueIsEmpty(MyCircularQueue* obj);
    if(myCircularQueueIsEmpty(obj))
        return 0;
    if(obj->head==obj->tail){
        obj->head=-1;
        obj->tail=-1;
        return 1;
    }
       obj->head=(obj->head+1)%obj->size;
    return 1;
  
}

/** Get the front item from the queue. */
int myCircularQueueFront(MyCircularQueue* obj) {
 int myCircularQueueIsEmpty(MyCircularQueue* obj);
 if(myCircularQueueIsEmpty(obj))
     return -1;
    return obj->data[obj->head]; 
}

/** Get the last item from the queue. */
int myCircularQueueRear(MyCircularQueue* obj) {
  int myCircularQueueIsEmpty(MyCircularQueue* obj);
  if(myCircularQueueIsEmpty(obj))
     return -1;
    return obj->data[obj->tail]; 
}

/** Checks whether the circular queue is empty or not. */
int myCircularQueueIsEmpty(MyCircularQueue* obj) {
  if(obj->head==-1)
      return 1;
    return 0;
}

/** Checks whether the circular queue is full or not. */
int myCircularQueueIsFull(MyCircularQueue* obj) {
  if((obj->tail+1)%obj->size==obj->head)
      return 1;
    return 0;
}

void myCircularQueueFree(MyCircularQueue* obj) {
    free(obj);
}
main()
{
	int i,x,y;
	int value[5]={1,2,3,4,5};
	MyCircularQueue* p;
	p=myCircularQueueCreate(5);
	printf("�������:\n");
	for(i=0;i<5;i++){
	x=myCircularQueueEnQueue(p,value[i]);
	printf("%d\n",x);//�����������Ϊ1����˵����ӳɹ���
	}
	printf("����Ԫ�ص�ֵΪ��%d\n",myCircularQueueFront(p));
	printf("��βԪ�ص�ֵΪ��%d\n",myCircularQueueRear(p));
	printf("������1Ϊ����%d\n",myCircularQueueIsFull(p));
	printf("���ݳ���:\n");
	for(i=0;i<5;i++){
	y=myCircularQueueDeQueue(p);
	printf("%d\n",y);//�����������Ϊ1����˵�����ӳɹ���
	}
	printf("�пգ�1Ϊ�գ�%d\n",myCircularQueueIsEmpty(p));
}


