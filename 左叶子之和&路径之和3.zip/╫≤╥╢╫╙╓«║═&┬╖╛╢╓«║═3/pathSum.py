# -*- coding: utf-8 -*-
"""
Created on Tue Dec 10 09:43:02 2019

@author: Administrator
"""
import json
class Solution(object):
    def pathSum(self, root, sum):
        """
        :type root: TreeNode
        :type sum: int
        :rtype: int
        """
        if not root:
            return 0

        # sums为node的父节点已能构成的和，返回最长可延伸到node结束的所有路径所能构成的和列表
        def dfs(node, sums):
            left = right = 0  #左右的值默认为0
            # 之前的和加当前结点值能构成的新和，以及从当前结点开始算的新和
            temp = [num + node.val for num in sums] + [node.val]
            #print(sums)
            if node.left:
                left = dfs(node.left, temp)  # 递归
            if node.right:
                right = dfs(node.right, temp)  # 递归
            print(temp)
            return temp.count(sum) + left + right
        return dfs(root, [])

class TreeNode:
     def __init__(self, x):
         self.val = x
         self.left = None
         self.right = None

def stringToTreeNode(input):

    input = input.strip()

    input = input[1:-1]

    if not input:

        return None
    inputValues = [s.strip() for s in input.split(',')]
    root = TreeNode(int(inputValues[0]))
    nodeQueue = [root]
    front = 0
    index = 1
    while index < len(inputValues):
        node = nodeQueue[front]
        front = front + 1
        item = inputValues[index]
        index = index + 1
        if item != "null":
            leftNumber = int(item)
            node.left = TreeNode(leftNumber)
            nodeQueue.append(node.left)
        if index >= len(inputValues):
            break
        item = inputValues[index]
        index = index + 1
        if item != "null":
            rightNumber = int(item)
            node.right = TreeNode(rightNumber)
            nodeQueue.append(node.right)
    return root


def int2dArrayToString(input):

    return json.dumps(input)


def main():
    line = input("按层序输入树的结点，结点间以逗号隔开：")
    while True:
        try:
            root = stringToTreeNode(line)
            ret = Solution().pathSum(root,18)
            print(ret)
            break
        except StopIteration:
            break
        
if __name__ == '__main__':

    main()