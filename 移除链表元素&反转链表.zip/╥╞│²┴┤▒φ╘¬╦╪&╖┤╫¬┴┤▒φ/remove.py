class ListNode:
    def __init__(self, x):
         self.val = x
         self.next = None

class Solution:
    def removeElements(self, head, val):
        h = ListNode(-1) #head
        h.next = head
        p = h
        l=p.next
        while l:
            if l.val == val:
                p.next = l.next
                l = l.next
            else:
                p = p.next
                l = l.next
        return h.next

def createList():
    head = ListNode(0)
    cur = head
    n =eval(input("请输入链表长度："))
    a = []
    for i in range(0,n):
        c=eval(input("输入值："))
        a.append(c)
    for i in range(0,n):
        cur.next = ListNode(a[i])
        cur = cur.next
    return head

def printList(head):
    cur = head
    while cur != None:
        print(cur.val, '-->', end='')
        cur = cur.next
    print('NULL')

if __name__ == "__main__":
    head = createList()
    printList(head)
    res = Solution().removeElements(head, 
                  )
    printList(res)
